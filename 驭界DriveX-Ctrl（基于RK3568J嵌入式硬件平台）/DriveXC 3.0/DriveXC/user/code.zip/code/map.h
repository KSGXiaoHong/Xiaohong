/*
    地图应用程序头文件
*/

#pragma once

//绘制地图菜单主界面
void map_menu();
//显示什么地图，1中国地图，2湖南地图，3广东地图
void dis_map(lv_event_t *e);