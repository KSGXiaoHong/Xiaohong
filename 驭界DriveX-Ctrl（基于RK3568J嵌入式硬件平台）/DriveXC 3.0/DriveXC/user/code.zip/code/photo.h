/* 
    相册应用程序头文件
*/

#pragma once

#include "lv.h"

//滑动浏览照片函数
void photo();