/*
    用户交互界面头文件
*/
#pragma once

//消息函数
void message();
