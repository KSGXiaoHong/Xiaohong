#include "lv.h"

//消息函数
void message()
{

}

#define MAX 5//客户端最大值
//创建一个线程用来接收客户端请求
void* RecvToClient_thread(void* arg)
{
    //接收客户端套接字
    int client_fd = *((int*)arg);
    //设置线程属性分离，自动释放资源
    pthread_detach(pthread_self());
    printf("已连接客户端:fd=%d\n",client_fd);
    //存放从客户端读到的数据
    while(1)
    {
        char buf[1024] = {0};
        //从客户端读数据
        ssize_t ret = recv(client_fd , buf , sizeof(buf),0);
        if(ret <= 0)
        {
            if (recv_len < 0) perror("从客户端读数据出错");
        }
        if(strcmp(buf,"end\n") == 0)
        {
            break;
        }
        printf("收到客户端(fd=%d)数据:%s\n", client_fd, buf);
        // 回复客户端
        char *reply = "服务器已收到消息";
        send(client_fd, reply, strlen(reply), 0);
    }
    close(client_fd);
}

//服务器 server
int server()
{
    //创建一个套接字
    //指定协议族为IPV4协议、流式套接字、不知名
    int socket_fd = socket(AF_INET,SOCK_STREAM,0);
    if( socket_fd == -1 )
    {
        perror("服务器创建套接字失败");
        return -1;
    }
    //设置套接字端口号可重用
    int n = 1;
    setsockopt(socket_fd,SOL_SOCKET,SO_REUSEPORT,&n,sizeof(n));
    setsockopt(socket_fd,SOL_SOCKET,SO_REUSEADDR,&n,sizeof(n));
    //定义一个网络地址结构体 保存服务器的网络通信地址
    struct sockaddr_in s_addr;
    s_addr.sin_family = AF_INET;//IPV4协议
    s_addr.sin_addr.s_addr = inet_addr("172.130.1.238");//指定ip地址
    s_addr.sin_port = htons(2223);//制定端口号  主机字节序列转换成网络字节序列
    //绑定服务器的网络通信地址
    if(bind(socket_fd,(struct sockaddr*)&s_addr,(socklen_t)sizeof(s_addr))== -1)
    {
        perror("服务器绑定失败:");
        return -1;
    }
    //监听套接字 最多五个
    if(listen(socket_fd,MAX) == -1)
    {
        perror("服务器监听出错");
        close(socket_fd);
        return -1;
    }
    puts("服务器已启动");
    int client_socket[MAX] = {0};
    int i = 0;
    while(1)
    {
        struct sockaddr_in client_addr ;//保存客户端的网络通信地址
        socklen_t client_len = sizeof(client_addr) ; //保存客户端的网络通信地址的长度
        //阻塞客户端的连接请求
        int client_fd = accept(socket_fd,(struct sockaddr*)&client_addr,&client_len);
        if(client_fd == -1)
        {
            perror("连接客户端失败");
            close(client_fd);
            continue ;
        }
        printf("已连接客户端：IP=%s,端口=%d,fd=%d\n",
                net_ntoa(client_addr.sin_addr),
                ntohs(client_addr.sin_port),
                client_fd);
        //创建一个线程用来处理客户端
        pthread_t tid;
        pthread_create(&tid,NULL,client_thread,(void*)&client_fd);
    }
    close(socket_fd);
}

//控制线程同步退出 标志位
int exit_fg = 0;
//接收服务器数据线程
void* RecvToSercer_thread(void* arg)
{
    int client_fd = *(int*)arg;
    while(!exit_fg)
    {
        //select监听客户端套接字，设置超时（1秒）
        fd_set readfds;
        FD_ZERO(&readfds);
        FD_SET(client_fd, &readfds);  // 监听服务器数据
        struct timeval tv = {1, 0};   // 超时1秒
        //阻塞等待数据或超时
        int ret = select(client_fd + 1, &readfds, NULL, NULL, &tv);
        if (ret < 0) 
        {
            perror("接收select出错");
            break;
        } 
        else if (ret == 0) 
        {
            puts("timeout");
            continue;  // 超时，检查g_quit后继续循环
        }
        //检查是否就绪
        if(FD_ISSET(0, &readfds))
        {
            char buf[1024] = {0};
            // 接收服务器回复
            ssize_t recv_len = recv(client_fd, buf, sizeof(buf)-1, 0);
            if (recv_len <= 0) 
            {
                perror("接收失败或服务器断开");
                exit_fg = 1;
                break;
            }
            buf[recv_len] = '\0';
            //收到end退出
            if(strcmp(buf,"end") == 0)
            {
                exit_fg = 1;
                break;
            }
            printf("服务器回复：%s\n", buf);
        }
    }
}

//给服务器发数据线程
void* SendToSercer_thread(void* arg)
{
    //提取参数
    int client_fd = *(int*)arg;
    while(!exit_fg)
    {
        //select监听键盘输入，设置超时（1秒）
        fd_set readfds;
        FD_ZERO(&readfds);
        FD_SET(0, &readfds);  // 监听键盘,标准输入文件描述符为0
        struct timeval tv = {1, 0};   // 超时1秒
        //阻塞等待数据或超时
        int ret = select(0+1, &readfds, NULL, NULL, &tv);
        if (ret < 0) 
        {
            perror("发送select出错");
            break;
        } 
        else if (ret == 0) 
        {
            puts("timeout");
            continue;  // 超时，检查g_quit后继续循环
        }
        //检查是否就绪
        if(FD_ISSET(client_fd, &readfds))
        {
            char buf[1024] = {0};
            printf("请输入要发送的消息(输入end退出):");
            //强制刷新标准输出缓冲区
            fflush(stdout);
            //从键盘输入数据
            fgets(buf,sizeof(buf),stdin);
            // 移除换行符
            buf[strcspn(buf, "\n")] = '\0';
            //往服务器写数据
            if(send(client_fd , buf , strlen(buf),0) == -1)
            {
                perror("客户端写入失败");
                exit_fg = 1;
                break;
            }
            //输入end退出
            if(strcmp(buf,"end") == 0)
            {
                exit_fg = 1;
                break;
            }
        }
    }
}


//客户端 client,传入端口号和ip
int client(int argc , char* argv[])
{
    if(argc != 3)
    {
        printf("<IP> <port>\n");
        return -1 ;
    }
    //创建一个套接字
    //指定协议族为IPV4协议、流式套接字、不知名
    int client_fd = socket(AF_INET,SOCK_STREAM,0);
    if( client_fd == -1 )
    {
        perror("客户端套接字创建失败:");
        return -1;
    }
    //定义一个网络地址结构体，保存服务器的信息
    struct sockaddr_in server_addr;
    server_addr.sin_family = AF_INET;//IPV4协议
    server_addr.sin_port = htons(atoi(argv[2]));//端口号
    server_addr.sin_addr.s_addr = inet_addr(argv[1]);//ip
    //连接服务器
    if(connect(client_fd,(struct sockaddr*)&server_addr,(socklen_t)sizeof(server_addr)) == -1)
    {
        perror("连接服务器出错");
        return -1 ;
    }
    puts("连接成功");
    //创建线程接收服务器的消息
    pthread_t t1, t2;
    pthread_create(&t1, NULL, recv_thread, &client_fd);
    //创建线程给服务器发消息
    pthread_create(&t2, NULL, send_thread, &client_fd);
    //主线程等待子线程结束
    pthread_join(t1, NULL);
    pthread_join(t2, NULL);
    //关闭连接并退出
    close(client_fd);
    printf("已断开连接\n");
}
